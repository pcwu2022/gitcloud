

B = zeros(1,10);

P_convential = zeros(1,1025);
P_spilt = zeros(1,1025);
P_energy_saving = zeros(1,1025);
P_monotonic = zeros(1,1025);
P_Merged = zeros(1,1025);

for b10 = 0 : 1 : 1
    for b9 = 0 : 1 : 1
        for b8 = 0 : 1 : 1
            for b7 = 0 : 1 : 1
                for b6 = 0 : 1 : 1
                    for b5 = 0 : 1 : 1
                        for b4 = 0 : 1 : 1
                            for b3 = 0 : 1 : 1
                                for b2 = 0 : 1 : 1
                                    for b1 = 0 : 1 : 1
                         
    B = [b1 b2 b3 b4 b5 b6 b7 b8 b9 b10];
    n = 1 +b1 *512 + b2 * 256 + b3 * 128 + b4 * 64 + b5 * 32 + b6 * 16 + b7 * 8 + b8 * 4 + b9 * 2 + b10 * 1;
  %  P_convential(n) = convential(B); 
  %  P_spilt(n) = spilt(B);
  %  P_energy_saving(n) = energy_saving(B);
    P_monotonic(n) = monotonic(B);
  %  P_Merged(n) = Merged(B);

    
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end  
end

  %  P_convential(1025) = P_convential(1024); 
  %  P_spilt(1025) = P_spilt(1024);
  %  P_energy_saving(1025) = P_energy_saving(1024);
    P_monotonic(1025) = P_monotonic(1024);
  %  P_Merged(1025) = P_Merged(1024);


up = 16;
y = 0:up:1024;
figure(2);
xlabel('Output Code');
ylabel('Switching Energy [CVref^2]');
%plot(y,P_convential(1:up:1025),'-rx'); hold on
%plot(y,P_spilt(1:up:1025),'-yx'); hold on
%plot(y,P_energy_saving(1:up:1025),'-gx'); hold on
plot(y,P_monotonic(1:up:1025),'-bx'); hold on
%plot(y,P_Merged(1:up:1025),'-mx'); hold on

xlim([0 1024]);
xlabel('Codes');
ylabel('C * VDD^2'); 
%legend('Conventional' , 'Spilt' , 'Energy Saving' , 'Monotonic' , 'Merged(Vcm-Based)');
