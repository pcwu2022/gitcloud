function Power=monotonic(B)


C = [ 256 128 64 32 16 8 4 2 1 1];
Csum = 512;

Vref = 1;
Vup = 0;
Vdown = 0;

Cup = 0;
Cdown = 0;

Psum = 0;
Psumu = 0;
Psumd = 0;

Vup_new = 0;
Vdown_new = 0;

for i = 0 : 1 :9
    if i == 0        % top-plate sampling not switching
        Cup = Csum;  % the value of capacitor connect to VDD
        Vup = Vup;
        Cdown = Csum; % the value of capacitor connect to VDD
        Vdown = Vdown;
        Psum =   0 * Vref * Vref;
       
    elseif B(i) == 1
       % up 
       Cup = Cup - C(i); % the value of capacitor connect to VDD
       Vup_new = Vup - Vref * C(i) / Csum;
       Psumu = Psumu + Cup * Vref * (Vup - Vup_new ) ;
       %      ��POWER + �쥻���WVref��C��POWER + �s���WVref��C20��POWER

      elseif B(i) == 0

       Cdown = Cdown - C(i);    % the value of capacitor connect to VDD
       Vdown_new = Vdown - Vref *  C(i) / Csum;
       Psumd = Psumd + Cdown * Vref * (Vdown - Vdown_new);
       %      ��POWER + �쥻���WVref��C��POWER + �s���WVref��C20��POWER
    end
       Vup = Vup_new;
       Vdown = Vdown_new;
end

       Power = Psum + Psumu + Psumd;
end
