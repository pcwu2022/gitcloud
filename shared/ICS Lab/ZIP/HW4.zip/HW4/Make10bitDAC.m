function cap = Make10bitDAC(C1)



end
