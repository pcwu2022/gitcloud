function cap = randomcap_unit(s)


end