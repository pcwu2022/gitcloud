

%Matlab behavior model for Mismatch (MoonFox)

% Linearity Test
% by gppo 2014/1/23
%% input
clear all;
N=10; %resolution
Number = 16384;

S = 0.02;    %Capacitor mismatch (STD)
repeat = 100; %repeat time

%Cp = [ 256 128 64 32 16 8 4 2 1 1];  %DACp
%Cn = [ 256 128 64 32 16 8 4 2 1 1];  %DACn

CodeWeighting = [512 256 128 64 32 16 8 4 2 1]; %Weighting


%% Static performance

INL=zeros(2^N,1);
DNL=zeros(2^N,1);

 for Z = 1 : 1 : repeat
Output_static = zeros(2*Number + 1,1);


 C1 = randomcap_unit(S);   % produce all unit capacitors for DACp
 C2 = randomcap_unit(S);   % produce all unit capacitors for DACn
 
 % for userdefine
 Cp = Make10bitDAC(C1);    %combine these unit capacitors into binary array
 Cn = Make10bitDAC(C2);




 for n = -1*Number : 1 : 1*Number
     vip =    n  / Number + 1;  
     vin =  - n  / Number + 1;   %vin&vip ramp wave, common mode = 1
     
     Code_static = Mono_10bit(vip,vin,Cp,Cn);    %SAR ADC
     
     k = n+1*Number+1;
     
     for u= 1:1:N 
     Output_static(k) = Code_static(u) * CodeWeighting(u) + Output_static(k); %binary to decimal
     end

 end



% --------------INL DNL calculation-----------------
Output_static=round(Output_static);
NumCode=length(Output_static);
% the number of codes between 1 ~ (MAXcode-1)
NumCode_use=0;
code_count=zeros(2^N,1);
for i=1:NumCode
    if(Output_static(i)~=0 && Output_static(i)~=2^N-1)
        NumCode_use=NumCode_use+1;        
        code_count(Output_static(i)+1)=code_count(Output_static(i)+1)+1;
    end
end

idealCodeWidth=NumCode_use/(2^N-2);
DNL =(code_count-idealCodeWidth)./idealCodeWidth;
DNL(1)=0; DNL(2^N)=0;

for i=2:2^N
    INL(i)=INL(i-1)+DNL(i);
end




i=0:2^N-1;

figure(1); hold all
plot(i,DNL);
xlabel('DNL ');
ylabel('Code (LSB)'); 
xlim([0 2^N-1]);

figure(2);
plot(i,INL); hold all
xlabel('INL');
ylabel('Code (LSB)'); 
xlim([0 2^N-1]);


end

%% Dynamic performance
format long e;

ENOB_mismatch = zeros(repeat,1);

for Z = 1 : 1 : repeat
    
 C1 = randomcap_unit(S);
 C2 = randomcap_unit(S);
 
 % for userdefine
 Cp = Make10bitDAC(C1);
 Cn = Make10bitDAC(C2);
    
    
% parameter
   OSR=1; 
   fs=50*10^6; %50MHz
  
   Ne=16384*8;
   Me=12233;
   fi=(fs/Ne)*Me;
   BW=fs/(2*OSR);
   Meg = (2^N-1)/(2^N);
   Output_fft = zeros( Ne , 1 ) ;
   
   for n= 1 : 1 : Ne
     vip = Meg*sin(2*pi*fi*n*2*10^(-8)) + 1; %vin&vip sine wave, common mode = 1
     vin =-Meg*sin(2*pi*fi*n*2*10^(-8)) + 1;

     Code_fft = Mono_10bit(vip,vin,Cp,Cn);    %SAR ADC
     
     for u= 1:1:N
     Output_fft(n) = Code_fft(u) * CodeWeighting(u) + Output_fft(n); %Waighting
     end
     
   end
   
   
% --------------ENOB calculation-----------------
yb = Output_fft;
% FFT
   yk1=fft(yb);
   yk=abs(yk1);
   f=fs*(0:Ne-1)/Ne;
   %Pyy=yk.*yk/((N/2)^2);   
   Pyy=yk.*conj(yk);%/(realpow(N/2,2));   
   %Pyy=yk.*conj(yk)/((N/2)^2);   
%=====================check zero==================
   Pyy = Pyy+1e-9;
%=====================check zero==================
   Pyy10=10*log10(Pyy);
   
   Pyy_ktk = Pyy10;
   [v,pts_in] = max(Pyy_ktk(2:Ne));
   pts_in = pts_in +1;
   figure(3);
   max_tone=10*log10(Pyy(pts_in));
   Pyy_con = 10*log10(Pyy)-max_tone;
   plot(f(2:Ne/2)/1e6,10*log10(Pyy(2:Ne/2))-max_tone,'-rx'); %hold on;
   xlabel('Frequency (MHz)');
   ylabel('Y[k](dB)');
   title('Output');
   ylim([-120 0]);
   grid on;
   
%**************************************************
pts_bw=fix(Ne/2)+1;

pwr_inp=sum(Pyy(pts_in-1:pts_in+1));          % signal power
pwr_inb_nh=(sum(Pyy(2:pts_in-2))+sum(Pyy(pts_in+2:pts_bw)));   %noise power
snrdbw=10*log10(pwr_inp)-10*log10(pwr_inb_nh);      %SNDR
ENOB_mismatch(Z)=(snrdbw-1.76)/6.02;   %ENOB

end

ENOB_MEAN = mean(ENOB_mismatch)
ENOB_STD = std(ENOB_mismatch)

figure(41)
hist(ENOB_mismatch)
xlim([9 10]);
xlabel('ENOB (bits)');
ylabel('Counts'); 



