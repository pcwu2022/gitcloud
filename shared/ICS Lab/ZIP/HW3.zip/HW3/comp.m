function out = comp(vip,vin,noise)

vnoise = noise * randn(1,1); % because the parameter "noise" is STD, we change it to a voltage


if (????????????)
    out = 0;
else out = 1;

end


end