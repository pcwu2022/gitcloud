function cap = para_cap(vi)
Vcm = 1;
cdif = 0.3;
cmax = 1;
Ccommon = 4;


format long e;

vi = 2 - vi;
if vi > Vcm    
a = -((vi-1.5*Vcm) ^ 2 - (0.5*Vcm)^2)  / ((0.5*Vcm)^2);

else
a = +((vi-0.5*Vcm) ^ 2 - (0.5*Vcm)^2)  / ((0.5*Vcm)^2);
end
cap = +a * cdif + (vi*cmax)/2 + Ccommon ;


% if vi > Vcm    
% a = -((vi-1.5*Vcm) ^ 2 - (0.5*Vcm)^2)  / ((0.5*Vcm)^2);
% 
% else
% a = +((vi-0.5*Vcm) ^ 2 - (0.5*Vcm)^2)  / ((0.5*Vcm)^2);
% end
% cap = +a * cdif + (vi*cmax)/2 + Ccommon ;

%cap = 0;


end
